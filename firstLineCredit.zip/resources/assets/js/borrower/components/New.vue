<template>
    <div class="row">
        <div class="col-sm-10 offset-1">
            <horizontal-stepper
                    :steps="borrowerSteps"
                    :top-buttons="true"
                    @completed-step="completeStep"
                    @active-step="isStepActive"
                    @stepper-finished="formEnd"

            >
            </horizontal-stepper>
        </div>
    </div>

</template>
<script>
    import HorizontalStepper from 'vue-stepper';
    import PersonalDetails from './PersonalDetails.vue';
    import NextOfKin from './NextOfKin.vue';
    import BankDetails from './BankDetails.vue';
    import ResidenceDetails from './Residence.vue';
    import WorkDetails from './WorkDetails.vue';
    import RefereeDetails from './RefereesDetails.vue';
    import EndForm from './EndRegistration.vue';
    export default{
        components: {
            HorizontalStepper
        },
        data(){
            return {
                borrowerSteps: [
                    {
                        icon: 'alarm',
                        name: 'first',
                        title: 'Personal Details',
                        subtitle: 'Borrower Personal Details',
                        component: PersonalDetails,
                        completed: false

                    },
                    {
                        icon: 'explore',
                        name: 'second',
                        title: 'Next of Kin',
                        subtitle: 'Borrower Next of Kin Details',
                        component: NextOfKin,
                        completed: false

                    },
                    {
                        icon: 'payment',
                        name: 'third',
                        title: 'Bank Details',
                        subtitle: 'Borrower Bank Details',
                        component: BankDetails,
                        completed: false

                    },
                    {
                        icon: 'navigation',
                        name: 'four',
                        title: 'Residence Details',
                        subtitle: 'Borrower Residence Details',
                        component: ResidenceDetails,
                        completed: false

                    },
                    {
                        icon: 'place',
                        name: 'five',
                        title: 'Work Details',
                        subtitle: 'Borrower Work Details',
                        component: WorkDetails,
                        completed: false

                    },

                    {
                        icon: 'person',
                        name: 'six',
                        title: 'Referee Details',
                        subtitle: 'Borrower Referee Details',
                        component: RefereeDetails,
                        completed: false

                    },
                    {
                        icon: 'close',
                        name: 'seven',
                        title: 'End Registration',
                        subtitle: 'End of Registration',
                        component: EndForm,
                        completed: false

                    },

                ]
            }
        },
        methods: {
            // Executed when @completed-step event is triggered
            completeStep(payload) {
                this.borrowerSteps.forEach((step) => {
                    if (step.name === payload.name) {
                        step.completed = true;
                    }
                })
            },
            // Executed when @active-step event is triggered
            isStepActive(payload) {
                this.borrowerSteps.forEach((step) => {

                    if (step.name === payload.name) {

                        if(step.completed === true) {
                            step.completed = false;
                        }
                    }
                })
            },
            // Executed when @stepper-finished event is triggered
            formEnd(payload) {

                window.location.href = '/teller/dashboard'
            }
        }
    }

</script>
<style lang="scss">



</style>