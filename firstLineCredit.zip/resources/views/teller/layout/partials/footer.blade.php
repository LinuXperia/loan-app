<footer class="app-footer" style="margin-top: 20px">
    <span><a href="">First Line Credit</a> © @php echo date('Y') @endphp.</span>
    <span class="ml-auto">Powered by <a href="">Willow Ventures</a></span>
</footer>