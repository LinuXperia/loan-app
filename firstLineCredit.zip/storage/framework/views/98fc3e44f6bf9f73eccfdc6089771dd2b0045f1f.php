<!-- Breadcrumb -->
<ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="<?php echo e(route('teller.dashboard')); ?>">Home</a></li>
    <li class="breadcrumb-item active"><?php echo e($page); ?></li>

</ol>