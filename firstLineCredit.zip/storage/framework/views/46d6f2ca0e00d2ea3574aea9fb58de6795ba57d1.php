<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo e(config('app.name')); ?></title>

    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/simple-line-icons/2.4.1/css/simple-line-icons.css">

    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">

    <?php echo $__env->yieldContent('styles'); ?>

</head>

<body class="app header-fixed sidebar-fixed aside-menu-fixed aside-menu-hidden">

<div id="app">
    <?php echo $__env->make('teller.layout.partials.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="app-body">

    <?php echo $__env->make('teller.layout.partials.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <!-- Main content -->
        <main class="main">

            <?php echo $__env->make('teller.layout.partials.breadcrumps', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <div class="container-fluid">
                <div class="animated fadeIn">

                    <?php echo $__env->yieldContent('content'); ?>

                </div>

            </div>
            <!-- /.conainer-fluid -->
        </main>

        

    </div>

</div>
    <?php echo $__env->make('teller.layout.partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- CoreUI main scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <script src="<?php echo e(asset('js/scripts.js')); ?>"></script>

    <?php echo $__env->yieldContent('scripts'); ?>

</body>
</html>