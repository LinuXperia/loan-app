import mainNav from './MainNav';

export default [...mainNav]

