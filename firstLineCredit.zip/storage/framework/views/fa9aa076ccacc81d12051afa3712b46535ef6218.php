<?php $__env->startSection('content'); ?>

    <new-borrower></new-borrower>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('teller.layout.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>