<!-- Breadcrumb -->
<ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="{{ route('teller.dashboard') }}">Home</a></li>
    <li class="breadcrumb-item active">{{ $page }}</li>

</ol>