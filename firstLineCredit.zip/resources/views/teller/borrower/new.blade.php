@extends('teller.layout.main')

@section('content')

    <new-borrower></new-borrower>

@endsection
